"""MCP Server for AllerPredict AI"""
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types
import json
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).parent.parent))

from agents.crew_orchestrator import AllerPredictCrew

# Initialize server and crew
server = Server("allerpredict-ai")
crew = AllerPredictCrew()

@server.list_tools()
async def list_tools() -> list[types.Tool]:
    """List all available MCP tools"""
    return [
        types.Tool(
            name="analyze_product",
            description="Analyze a product for allergens, risks, and get safe alternatives using multi-agent AI system",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_query": {
                        "type": "string",
                        "description": "Name or description of the product to analyze"
                    },
                    "user_allergies": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional: List of user's known allergies"
                    },
                    "detailed": {
                        "type": "boolean",
                        "description": "If true, use full multi-agent analysis (slower but comprehensive)"
                    }
                },
                "required": ["product_query"]
            }
        ),
        types.Tool(
            name="find_alternatives",
            description="Find safe alternative products that avoid specific allergens",
            inputSchema={
                "type": "object",
                "properties": {
                    "allergens_to_avoid": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of allergens to avoid (e.g., ['peanuts', 'dairy'])"
                    },
                    "category": {
                        "type": "string",
                        "description": "Optional: Product category to search in"
                    }
                },
                "required": ["allergens_to_avoid"]
            }
        ),
        types.Tool(
            name="get_product_info",
            description="Get detailed information about a specific product",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_name": {
                        "type": "string",
                        "description": "Exact or partial name of the product"
                    }
                },
                "required": ["product_name"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    """Handle tool execution"""
    
    if name == "analyze_product":
        product_query = arguments["product_query"]
        user_allergies = arguments.get("user_allergies", [])
        detailed = arguments.get("detailed", False)
        
        # Build user profile if allergies provided
        user_profile = {"allergies": user_allergies} if user_allergies else None
        
        # Run analysis
        if detailed:
            result = crew.analyze_product(product_query, user_profile)
        else:
            result = crew.quick_analyze(product_query)
        
        # Format response
        if "error" in result:
            return [types.TextContent(type="text", text=f"Error: {result['error']}")]
        
        response = f"""**AllerPredict AI Analysis**

**Product:** {result['product']['name']} by {result['product'].get('brand', 'Unknown')}
**Category:** {result['product'].get('category', 'Unknown')}
**Known Allergens:** {', '.join(result['product'].get('allergens', [])) or 'None'}
**Ethical Score:** {result['product'].get('ethical_score', 'N/A')}/10

**Analysis:**
{result.get('analysis', 'No detailed analysis available')}

**Safe Alternatives:**
"""
        for alt in result.get('alternatives', [])[:3]:
            response += f"\n- {alt['name']} by {alt['brand']} (Score: {alt['ethical_score']}/10)"
        
        return [types.TextContent(type="text", text=response)]
    
    elif name == "find_alternatives":
        allergens = arguments["allergens_to_avoid"]
        alternatives = crew.rag.find_alternatives(allergens, exclude_id=-1)
        
        response = f"**Safe Alternatives (Avoiding: {', '.join(allergens)})**\n\n"
        for alt in alternatives[:5]:
            response += f"✓ {alt['name']} by {alt['brand']}\n"
            response += f"  Allergens: {', '.join(alt['allergens']) or 'None'}\n"
            response += f"  Score: {alt['ethical_score']}/10\n\n"
        
        return [types.TextContent(type="text", text=response)]
    
    elif name == "get_product_info":
        product_name = arguments["product_name"]
        results = crew.rag.search(product_name, top_k=1)
        
        if not results:
            return [types.TextContent(type="text", text="Product not found")]
        
        product = results[0]
        info = f"""**{product['name']}** by {product['brand']}

**Category:** {product['category']}
**Ingredients:** {', '.join(product['ingredients'])}
**Allergens:** {', '.join(product['allergens']) or 'None'}
**Ethical Score:** {product['ethical_score']}/10
**Certifications:** {', '.join(product['certifications']) or 'None'}

**Description:** {product['description']}
**Company:** {product['company_info']}
"""
        return [types.TextContent(type="text", text=info)]
    
    raise ValueError(f"Unknown tool: {name}")

async def main():
    """Run MCP server"""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
