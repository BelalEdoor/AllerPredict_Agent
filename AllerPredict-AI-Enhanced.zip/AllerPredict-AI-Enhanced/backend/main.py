"""FastAPI Main Application"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent))

from agents.crew_orchestrator import AllerPredictCrew

# Initialize FastAPI
app = FastAPI(
    title="AllerPredict AI",
    description="Intelligent Product Analysis System with Multi-Agent AI",
    version="2.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize AI Crew
crew = AllerPredictCrew(metadata_path="data/metadata.json")

# Pydantic Models
class ProductQuery(BaseModel):
    query: str
    user_allergies: Optional[List[str]] = None
    detailed_analysis: bool = False

class AlternativeRequest(BaseModel):
    allergens: List[str]
    category: Optional[str] = None

# API Endpoints
@app.get("/")
async def root():
    """API health check"""
    return {
        "status": "active",
        "service": "AllerPredict AI",
        "version": "2.0.0",
        "features": ["RAG", "MCP", "CrewAI", "Multi-Agent Analysis"]
    }

@app.get("/products")
async def get_products():
    """Get all products in database"""
    return {"products": crew.rag.products}

@app.post("/analyze")
async def analyze_product(request: ProductQuery):
    """
    Analyze a product using multi-agent AI system
    
    - **query**: Product name or description
    - **user_allergies**: Optional list of user allergies
    - **detailed_analysis**: Use full crew analysis (slower but comprehensive)
    """
    try:
        # Build user profile
        user_profile = None
        if request.user_allergies:
            user_profile = {"allergies": request.user_allergies}
        
        # Run analysis
        if request.detailed_analysis:
            result = crew.analyze_product(request.query, user_profile)
        else:
            result = crew.quick_analyze(request.query)
        
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        
        return result
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/alternatives")
async def find_alternatives(request: AlternativeRequest):
    """Find safe alternative products"""
    try:
        alternatives = crew.rag.find_alternatives(
            allergens=request.allergens,
            exclude_id=-1
        )
        
        # Filter by category if provided
        if request.category:
            alternatives = [
                alt for alt in alternatives 
                if alt.get('category', '').lower() == request.category.lower()
            ]
        
        return {
            "allergens_avoided": request.allergens,
            "alternatives": alternatives[:5]
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/search/{query}")
async def search_products(query: str, limit: int = 5):
    """Search for products by name or description"""
    try:
        results = crew.rag.search(query, top_k=limit)
        return {"query": query, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/product/{product_id}")
async def get_product(product_id: int):
    """Get specific product by ID"""
    for product in crew.rag.products:
        if product['id'] == product_id:
            return product
    raise HTTPException(status_code=404, detail="Product not found")

# Health check for monitoring
@app.get("/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "rag_loaded": len(crew.rag.products) > 0,
        "agents_initialized": True,
        "models": {
            "embeddings": "all-MiniLM-L6-v2",
            "llm": "llama3.2 (Ollama)"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
